#include "funcoes.hpp" //cahamando a funcao
#include <iostream>

// Comuandos para compilar e executar respectivamente:
// g++ -I./include src/codigo.cpp src/operadores.cpp -o calculadora
// ./calculadora (aqui é a pasta)

int main() { 

    int num1;
    int num2;
    int operador; //sinalizar a operacao q vai fzr

    std::cout << "Digite o primeiro numero da operação: \n";
    std::cin >> num1;
    std::cout << "Digite o segundo numero da operação: \n";
    std::cin >> num2;
    std::cout << "Digite a operação que voce deseja: \n";
    std::cout << "1 - soma | 2- subtração | 3- multiplicação | 4- divisão \n\n"; 
    std::cin >> operador; //ler sinalizador

    switch (operador)
    {
    case 1:
        std::cout << somar(num1, num2);
        std::cout << "\n*********************\n";
        break;
    case 2:
        std::cout << subtrair(num1, num2);
        std::cout << "\n*********************\n";
        break;
    case 3:
        std::cout << multiplicar(num1, num2);
        std::cout << "\n*********************\n";
        break;
    case 4:
    if(num2 > 0 || num2 < 0) { //denominador
        std::cout << dividir(num1, num2); 
        std::cout << "\n*********************\n";
        } else if (num2 == 0) std::cout << "\nERRO!!\n";
        break;
    
    
    default:
    std::cout << "\n*********************\n";
    std::cout << "\nNUMERO INVALIDO\n";
    std::cout << "\n*********************\n";
        break;
    }
    
    return 0;
}
