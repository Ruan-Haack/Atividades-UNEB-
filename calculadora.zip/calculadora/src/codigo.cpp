#include "funcoes.hpp" //cahamando a funcao
#include <iostream>

// Comuandos para compilar e executar respectivamente:
// g++ -I./include src/codigo.cpp src/operadores.cpp -o calculadora
// ./calculadora (aqui é a pasta)

int main() { 

    int num1;
    int num2;
    int operador; //sinalizar a operacao q vai fzr

    std::cout << "Digite o primeiro numero da operação: \n";
    std::cin >> num1;
    std::cout << "Digite o segundo numero da operação: \n";
    std::cin >> num2;
    std::cout << "Digite a operação que voce deseja: \n";
    std::cout << "1 - soma | 2- subtração | 3- multiplicação | 4- divisão \n\n"; 
    std::cin >> operador; //ler sinalizador

    if (operador == 1 || operador == 2 || operador == 3 || operador == 4 ) {

        if(operador == 1 ) {
            std::cout << somar(num1, num2);
            std::cout << "\n*********************\n";
        } else if (operador == 2) {
            std::cout << subtrair(num1, num2);
            std::cout << "\n*********************\n";
        } else if (operador == 3) {
            std::cout << multiplicar(num1, num2);
            std::cout << "\n*********************\n";
        } else if (operador == 4) { 
            std::cout << dividir(num1, num2);
            std::cout << "\n*********************\n";
        }


    } else std::cout << "\nNUMERO INVALIDO!!!!! \n ";
 
    return 0;
}
